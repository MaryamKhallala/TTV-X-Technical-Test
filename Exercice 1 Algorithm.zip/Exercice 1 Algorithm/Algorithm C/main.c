#include <stdio.h>
#include <stdlib.h>

int main()
{
    for(int i=1;i<=100;i++)
    {

         if(i%3==0)
           {
               printf("Hello, ");
               i++;
           }
        if(i%5==0)
           {
               printf("World, ");
               i++;
           }
        if(i%7==0)
           {
               printf("YOO, ");
               i++;
           }
           if(i!=101)
            printf("%d, ",i);


    }
    return 0;
}
