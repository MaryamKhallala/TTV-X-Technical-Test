
public class Algorithm {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		for(int i=1;i<=100;i++)
	    {

	         if(i%3==0)
	           {
	               System.out.print("Hello, ");
	               i++;
	           }
	        if(i%5==0)
	           {
	        	System.out.print("World, ");
	               i++;
	           }
	        if(i%7==0)
	           {
	        	System.out.print("YOO, ");
	               i++;
	           }
	           if(i!=101)
	           {
	        	   System.out.print(i);
	        	   System.out.print(" ,");
	           } 


	    }

	}

}
